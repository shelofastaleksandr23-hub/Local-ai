Local AI: приложение для Android с локальной нейросетью (llama.cpp).

Состав проекта:
- app/src/main/assets/index.html  интерфейс (чат, настройки, модели)
- app/src/main/java/...           Kotlin: WebView и мост (файлы, загрузка, запуск llama-server)
- движок llama-server собирается на GitHub Actions и кладётся в
  app/src/main/jniLibs/arm64-v8a/libllamaserver.so (в архиве его нет)

Сборка: см. .github/workflows/build.yml в репозитории.
