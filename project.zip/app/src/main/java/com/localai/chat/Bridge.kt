package com.localai.chat

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread

/**
 * Мост между страницей (index.html) и телефоном:
 * файлы моделей, загрузка, запуск и остановка llama-server.
 */
class Bridge(private val act: Activity, private val web: WebView) {

    private val modelsDir = File(act.filesDir, "models").apply { mkdirs() }
    private val cancels = ConcurrentHashMap<String, Boolean>()
    private var proc: Process? = null

    @Volatile private var gen = 0
    @Volatile private var state = "stopped"

    // ---------- отправка событий в страницу ----------

    private fun emit(o: JSONObject) {
        val js = "window.onNative&&window.onNative(" + JSONObject.quote(o.toString()) + ")"
        act.runOnUiThread { web.evaluateJavascript(js, null) }
    }

    private fun setState(s: String) {
        state = s
        emit(JSONObject().put("type", "server").put("state", s))
    }

    private fun log(line: String) {
        emit(JSONObject().put("type", "log").put("line", line.take(400)))
    }

    private fun fail(msg: String, name: String = "") {
        emit(JSONObject().put("type", "dlerror").put("name", name).put("msg", msg))
    }

    private fun safe(name: String): String = File(name).name.ifBlank { "model.gguf" }

    private fun fileOf(name: String) = File(modelsDir, safe(name))

    // ---------- модели ----------

    @JavascriptInterface
    fun listModels(): String {
        val arr = JSONArray()
        modelsDir.listFiles()
            ?.filter { it.isFile && it.name.endsWith(".gguf", ignoreCase = true) }
            ?.sortedBy { it.name }
            ?.forEach { arr.put(JSONObject().put("name", it.name).put("size", it.length())) }
        return arr.toString()
    }

    @JavascriptInterface
    fun deleteModel(name: String) {
        fileOf(name).delete()
    }

    @JavascriptInterface
    fun cancelDownload(name: String) {
        val n = safe(name)
        if (cancels.containsKey(n)) cancels[n] = true
    }

    private fun open(url: String): HttpURLConnection {
        var u = url
        repeat(8) {
            val c = URL(u).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 20000
            c.readTimeout = 30000
            c.setRequestProperty("User-Agent", "LocalAI-Android")
            val code = c.responseCode
            if (code in 300..399) {
                u = URL(URL(u), c.getHeaderField("Location")).toString()
                c.disconnect()
            } else if (code == 200) {
                return c
            } else {
                c.disconnect()
                throw Exception("HTTP $code")
            }
        }
        throw Exception("слишком много перенаправлений")
    }

    private fun pump(inp: InputStream, dest: File, name: String, total: Long, isCancelled: () -> Boolean) {
        inp.use { i ->
            dest.outputStream().use { o ->
                val buf = ByteArray(256 * 1024)
                var done = 0L
                var last = 0L
                while (true) {
                    if (isCancelled()) throw Exception("")
                    val r = i.read(buf)
                    if (r < 0) break
                    o.write(buf, 0, r)
                    done += r
                    val now = System.currentTimeMillis()
                    if (now - last > 400) {
                        last = now
                        emit(
                            JSONObject().put("type", "progress").put("name", name)
                                .put("done", done).put("total", total)
                        )
                    }
                }
            }
        }
    }

    @JavascriptInterface
    fun downloadModel(url: String, name: String) {
        val n = safe(name)
        if (cancels.putIfAbsent(n, false) != null) return
        thread {
            val part = File(modelsDir, "$n.part")
            try {
                val c = open(url)
                pump(c.inputStream, part, n, c.contentLengthLong) { cancels[n] == true }
                c.disconnect()
                val dst = fileOf(n)
                dst.delete()
                if (!part.renameTo(dst)) throw Exception("не удалось сохранить файл")
                emit(JSONObject().put("type", "downloaded").put("name", n))
            } catch (e: Exception) {
                part.delete()
                fail(e.message ?: "ошибка", n)
            } finally {
                cancels.remove(n)
            }
        }
    }

    @JavascriptInterface
    fun pickModel() {
        act.runOnUiThread {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }
            @Suppress("DEPRECATION")
            act.startActivityForResult(i, MainActivity.REQ_PICK)
        }
    }

    fun importUri(uri: Uri) {
        thread {
            try {
                var name = "model.gguf"
                act.contentResolver.query(uri, null, null, null, null)?.use { c ->
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0 && c.moveToFirst()) name = c.getString(i)
                }
                val n = safe(name)
                if (!n.endsWith(".gguf", ignoreCase = true)) {
                    fail("Нужен файл с расширением .gguf")
                    return@thread
                }
                val total = act.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L
                val inp = act.contentResolver.openInputStream(uri) ?: throw Exception("не удалось открыть файл")
                val part = File(modelsDir, "$n.part")
                try {
                    pump(inp, part, n, total) { false }
                    val dst = fileOf(n)
                    dst.delete()
                    if (!part.renameTo(dst)) throw Exception("не удалось сохранить файл")
                } catch (e: Exception) {
                    part.delete()
                    throw e
                }
                emit(JSONObject().put("type", "picked").put("name", n))
            } catch (e: Exception) {
                fail(e.message ?: "ошибка")
            }
        }
    }

    // ---------- сервер ----------

    @JavascriptInterface
    fun serverState(): String = state

    @Synchronized
    @JavascriptInterface
    fun startServer(file: String, ctx: Int, threads: Int, ngl: Int, batch: Int, port: Int) {
        stopServer()
        val model = fileOf(file)
        val exe = File(act.applicationInfo.nativeLibraryDir, "libllamaserver.so")
        if (!model.exists()) {
            log("Файл модели не найден: ${model.name}")
            setState("crashed")
            return
        }
        if (!exe.exists()) {
            log("В приложении нет движка llama-server")
            setState("crashed")
            return
        }

        // Если после прошлого запуска остался забытый процесс, он держит порт и память
        try {
            Runtime.getRuntime().exec(arrayOf("pkill", "-f", "libllamaserver")).waitFor()
            Thread.sleep(300)
        } catch (_: Exception) {
        }

        val my = ++gen
        setState("starting")

        thread {
            try {
                val cmd = listOf(
                    exe.absolutePath,
                    "-m", model.absolutePath,
                    "-c", ctx.toString(),
                    "-t", threads.toString(),
                    "-b", batch.toString(),
                    "-np", "1",
                    "--host", "127.0.0.1",
                    "--port", port.toString()
                )
                log(cmd.joinToString(" "))
                val p = ProcessBuilder(cmd).redirectErrorStream(true).directory(act.filesDir).start()
                synchronized(this) {
                    if (my != gen) {
                        p.destroyForcibly()
                        return@thread
                    }
                    proc = p
                }

                // Ждём, пока сервер загрузит модель и ответит на /health
                thread(isDaemon = true) {
                    while (my == gen && p.isAlive) {
                        try {
                            val c = URL("http://127.0.0.1:$port/health").openConnection() as HttpURLConnection
                            c.connectTimeout = 800
                            c.readTimeout = 800
                            val ok = c.responseCode == 200
                            c.disconnect()
                            if (ok) {
                                if (my == gen) setState("running")
                                break
                            }
                        } catch (_: Exception) {
                        }
                        try {
                            Thread.sleep(700)
                        } catch (_: InterruptedException) {
                            break
                        }
                    }
                }

                p.inputStream.bufferedReader().forEachLine { line ->
                    if (!line.contains("/health")) log(line)
                }
                val code = p.waitFor()
                log("Процесс завершён, код $code")
                if (my == gen) {
                    proc = null
                    setState("crashed")
                }
            } catch (e: Exception) {
                log("Ошибка запуска: ${e.message}")
                if (my == gen) setState("crashed")
            }
        }
    }

    @Synchronized
    @JavascriptInterface
    fun stopServer() {
        gen++
        proc?.destroyForcibly()
        proc = null
        setState("stopped")
    }
}
