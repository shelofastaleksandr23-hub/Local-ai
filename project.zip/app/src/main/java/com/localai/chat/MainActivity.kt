package com.localai.chat

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.webkit.ValueCallback
import android.os.Bundle
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var bridge: Bridge
    private var chooserCb: ValueCallback<Array<Uri>>? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val bg = Color.parseColor("#080A14")
        window.statusBarColor = bg
        window.navigationBarColor = bg

        web = WebView(this)
        web.setBackgroundColor(bg)
        setContentView(web)

        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowFileAccessFromFileURLs = true
            allowUniversalAccessFromFileURLs = true
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }

        web.webViewClient = WebViewClient()
        web.webChromeClient = object : WebChromeClient() {
            // Кнопки выбора файла на странице (скрепка, загрузка в GitHub)
            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                chooserCb?.onReceiveValue(null)
                chooserCb = callback
                return try {
                    @Suppress("DEPRECATION")
                    startActivityForResult(params!!.createIntent(), REQ_CHOOSE)
                    true
                } catch (e: Exception) {
                    chooserCb = null
                    false
                }
            }

            // Без этих методов alert() и confirm() из страницы в WebView не показываются
            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }

            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity)
                    .setMessage(message)
                    .setPositiveButton("OK") { _, _ -> result.confirm() }
                    .setNegativeButton("Отмена") { _, _ -> result.cancel() }
                    .setOnCancelListener { result.cancel() }
                    .show()
                return true
            }
        }

        bridge = Bridge(this, web)
        web.addJavascriptInterface(bridge, "Android")
        web.loadUrl("file:///android_asset/index.html")
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_PICK && resultCode == RESULT_OK) {
            data?.data?.let { bridge.importUri(it) }
        } else if (requestCode == REQ_CHOOSE) {
            chooserCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            chooserCb = null
        }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        // Сначала даём странице закрыть панель настроек, иначе выходим
        web.evaluateJavascript("(window.onBackBtn&&window.onBackBtn())") { r ->
            if (r != "true") finish()
        }
    }

    override fun onDestroy() {
        if (isFinishing) bridge.stopServer()
        super.onDestroy()
    }

    companion object {
        const val REQ_PICK = 1001
        const val REQ_CHOOSE = 1002
    }
}
